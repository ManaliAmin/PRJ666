<template>
  <v-layout column>
    <v-flex xs6>
      <panel title="Courses">
        <v-btn class="cyan accent-2"
          slot="action"
          @click="navigateTo({name: 'courses-create'})"
          light
          medium
          absolute
          right
          middle
          fab>
            <v-icon>add</v-icon>
          </v-btn>
        <div
        v-for="course in courses"
        class="course"
        :key="course.id">
          <v-layout>
            <v-flex xs6>
              <div class="course-title">
                {{course.title}}
              </div>
              <div class="course-author">
                {{course.author}}
              </div>
              <div class="course-teachingLevel">
                {{course.teachingLevel}}
              </div>

              <v-btn
                dark
                class="cyan"
                @click="navigateTo({
                  name: 'course',
                  params: {courseId: course.id}})">
                  View
              </v-btn>
            </v-flex>

            <v-flex xs6>
              <img class="course-image" :src="course.courseImage"/>
            </v-flex>

          </v-layout>
        </div>
      </panel>
    </v-flex>
  </v-layout>
</template>

<script>
import Panel from '@/components/Panel'
import CoursesService from '@/services/CoursesService'
export default {
  components: {
    Panel
  },
  data () {
    return {
      courses: null
    }
  },
  methods: {
    navigateTo (route) {
      this.$router.push(route)
    }
  },
  async mounted () {
    this.courses = (await CoursesService.index()).data
  }
}
</script>

<style scoped>
.course {
  padding: 20px;
  height: 330px;
  overflow: hidden;
}
.course-title {
  font-size: 30px;
}
.course-author {
  font-size: 24px;
}
.course-teachingLevel {
  font-size: 18px;
}
.course-image {
  width: 50%;
  margin: 0 auto;
}
</style>
