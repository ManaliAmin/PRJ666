<template>
        <panel title="Course Metadata">
          <v-layout>
            <v-flex xs6>
              <div class="course-title">
                {{course.title}}
              </div>
              <div class="course-author">
                {{course.author}}
              </div>
              <div class="course-teachingLevel">
                {{course.teachingLevel}}
              </div>

              <v-btn
              dark
              class="cyan"
              @click="navigateTo({
                name: 'course-edit',
                params: {
                  courseId: course.id
                }
              })">
              Edit
            </v-btn>
            </v-flex>
            <v-flex xs6>
              <img class="course-image" :src="course.courseImage" />
            </v-flex>
          </v-layout>
        </panel>
</template>

<script>
import Panel from '@/components/Panel'

export default {
  props: [
    'course'
  ],
  methods: {
    navigateTo (route) {
      this.$router.push(route)
    }
  },
  components: {
    Panel
  }
}
</script>

<style scoped>
.course {
  padding: 20px;
  height: 330px;
  overflow: hidden;
}
.course-title {
  font-size: 30px;
}
.course-author {
  font-size: 24px;
}
.course-teachingLevel {
  font-size: 18px;
}
.course-image {
  width: 70%;
  margin: 0 auto;
}
</style>
