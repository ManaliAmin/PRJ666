<template>
  <div>
    <v-layout>
      <v-flex xs6 class="ml-2">
        <course-metadata :course="course" />
      </v-flex>

      <v-flex xs6 class="ml-2">
        <Video :videoId="course.courseVideo"/>
      </v-flex>
    </v-layout>

    <v-layout>
      <v-flex xs6 class="ml-2">
        <description :course="course"/>
      </v-flex>

      <v-flex xs6 class="ml-2">
        <panel title="Whatever">
        </panel>
      </v-flex>
    </v-layout>

  </div>
</template>

<script>
import Description from './Description'
import Video from './Video'
import CourseMetadata from './CourseMetadata'
import CoursesService from '@/services/CoursesService'
import Panel from '@/components/Panel'

export default {
  data () {
    return {
      course: {}
    }
  },
  async mounted () {
    const courseId = this.$store.state.route.params.courseId
    this.course = (await CoursesService.show(courseId)).data
  },
  components: {
    Panel,
    CourseMetadata,
    Video,
    Description
  }
}
</script>

<style scoped>

</style>
