<template>
  <panel title="Video">
  <youtube
  :video-id="videoId"
  :player-width="500"
  :player-height="200">
  </youtube>
  </panel>
</template>

<script>
import Panel from '@/components/Panel'
import VueYouTubeEmbeded from 'vue-youtube-embed'

export default {
  props: [
    'videoId'
  ],
  components: {
    Panel,
    VueYouTubeEmbeded
  }
}
</script>

<style scoped>

<style>
