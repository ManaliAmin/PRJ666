<template>
  <v-toolbar fixed>

    <v-toolbar-title class="mr-4">
      <span class="home" @click="navigateTo({name: 'root'})">
      KnowledgeFlow
    </span>
    </v-toolbar-title>

    <v-toolbar-items>
      <v-btn
        flat
        @click="navigateTo({name: 'courses'})">
        Browse
      </v-btn>
    </v-toolbar-items>

    <v-spacer></v-spacer>

    <v-toolbar-items>
      <v-btn
        v-if="!$store.state.isUserLoggedIn"
        flat
        @click="navigateTo({name: 'login'})">
        Login
      </v-btn>

      <v-btn
        v-if="!$store.state.isUserLoggedIn"
        flat
        @click="navigateTo({name: 'register'})">
        Sign up
      </v-btn>

      <v-btn
        v-if="$store.state.isUserLoggedIn"
        flat
        @click="logout">
        logout
      </v-btn>
    </v-toolbar-items>

  </v-toolbar>
</template>

<script>
export default {
  methods: {
    navigateTo (route) {
      this.$router.push(route)
    },
    logout () {
      this.$store.dispatch('setToken', null)
      this.$store.dispatch('setUser', null)
      this.$router.push({
        name: 'root'
      })
    }
  }
}
</script>

<style scoped>
.home {
  cursor: pointer;
}

.home:hover {
  color:green;
}

</style>
