<template>
  <v-layout>
    <v-flex xs4>
      <panel title="Course Metadata">
        <v-text-field
          label="Title"
          required
          :rules="[required]"
          v-model="course.title"
        ></v-text-field>

        <v-text-field
          label="Author"
          required
          :rules="[required]"
          v-model="course.author"
        ></v-text-field>

        <v-text-field
          label="Teaching Level"
          required
          :rules="[required]"
          v-model="course.teachingLevel"
        ></v-text-field>

        <v-text-field
          label="Course Image"
          required
          :rules="[required]"
          v-model="course.courseImage"
        ></v-text-field>

        <v-text-field
          label="Course Video"
          required
          :rules="[required]"
          v-model="course.courseVideo"
        ></v-text-field>
      </panel>
    </v-flex>
    <v-flex xs8>
      <panel title="Description" class="ml-2">
      <v-textarea
        label="Description"
        required
        :rules="[required]"
        v-model="course.description"
       ></v-textarea>
     </panel>
     <br>
     <div class="danger-alert" v-if="error">{{error}}</div>
     <v-btn
     class="cyan"
     @click="createCourse">
     Create Course
     </v-btn>
     </v-flex>
  </v-layout>
</template>

<script>
import Panel from '@/components/Panel'
import CoursesService from '@/services/CoursesService'

export default {
  data () {
    return {
      course: {
        title: null,
        author: null,
        teachingLevel: null,
        description: null,
        courseImage: null,
        courseVideo: null
      },
      error: null,
      required: (value) => !!value || 'Required.'
    }
  },
  methods: {
    async createCourse () {
      this.error = null
      const areAllFieldsFilledIn = Object
        .keys(this.course)
        .every(key => !!this.course[key])
      if (!areAllFieldsFilledIn) {
        this.error = 'Please fill in all the required fields.'
        return
      }
      try {
        await CoursesService.post(this.course)
        this.$router.push({
          name: 'courses'
        })
      } catch (err) {
        console.log(err)
      }
    }
  },
  components: {
    Panel
  }
}
</script>

<style scope>
</style>
