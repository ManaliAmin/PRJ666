import Api from '@/services/Api'

export default {
  index () {
    return Api().get('courses')
  },
  show (courseId) {
    return Api().get(`courses/${courseId}`)
  },
  post (course) {
    return Api().post('courses', course)
  },
  put (course) {
    return Api().put(`courses/${course.id}, course`)
  }
}
