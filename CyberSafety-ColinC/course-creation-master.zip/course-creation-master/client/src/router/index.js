import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import Register from '@/components/Register'
import Login from '@/components/Login'
import Courses from '@/components/Courses'
import CreateCourse from '@/components/CreateCourse'
import ViewCourse from '@/components/ViewCourse/Index'
import EditCourse from '@/components/EditCourse'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'root',
      component: HelloWorld
    },
    {
      path: '/register',
      name: 'register',
      component: Register
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/courses',
      name: 'courses',
      component: Courses
    },
    {
      path: '/courses/create',
      name: 'courses-create',
      component: CreateCourse
    },
    {
      path: '/courses/:courseId',
      name: 'course',
      component: ViewCourse
    },
    {
      path: '/course/:courseId/edit',
      name: 'course-edit',
      component: EditCourse
    }
  ]
})
