const AuthenticationController = require('./controllers/AuthenticationController')
const AuthenticationControllerPolicy = require('./policies/AuthenticationControllerPolicy')
const CoursesController = require('./controllers/CoursesController')

module.exports = (app) => {
  app.post('/register',
    AuthenticationControllerPolicy.register,
    AuthenticationController.register)

  app.post('/login', AuthenticationController.login)

  app.get('/courses', CoursesController.index)

  app.get('/courses/:courseId', CoursesController.show)

  app.put('/courses/:courseId', CoursesController.put)

  app.post('/courses', CoursesController.post)
}
