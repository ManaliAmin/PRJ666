const {Course} = require('../models')

module.exports = {
  async index (req, res) {
    try {
      const courses = await Course.findAll({
        limit: 10
      })
      res.send(courses)
    } catch (err) {
      res.status(500).send({
        error: 'An error has occured trying to fetch the courses!'
      })
    }
  },
  async show (req, res) {
    try {
      const course = await Course.findById(req.params.courseId)
        res.send(course)
    } catch (err) {
      res.status(500).send({
        error: 'An error has occured trying to fetch the course!'
      })
    }
  },
  async post (req, res) {
    try {
      const course = await Course.create(req.body)
      res.send(course)
    } catch (err) {
      res.status(500).send({
        error: 'An error has occured trying to create the course!'
      })
    }
  },
  async put (req, res) {
    try {
      const course = await Course.update(req.body, {
        where: {
          id: req.params.courseId
        }
      })
      res.send(req.body)
    } catch (err) {
      res.status(500).send({
        error: 'An error has occured trying to update the course!'
      })
    }
  }
}
