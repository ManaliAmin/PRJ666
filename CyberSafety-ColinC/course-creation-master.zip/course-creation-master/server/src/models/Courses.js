module.exports = (sequelize, DataTypes) => {
  const Course = sequelize.define('Course', {
    title: DataTypes.STRING,
    author: DataTypes.STRING,
    teachingLevel: DataTypes.STRING,
    description: DataTypes.TEXT,
    courseImage: DataTypes.STRING,
    courseVideo: DataTypes.STRING
  })
  return Course
}
